# Flask Auto

Flask Auto es una librería para generar proyectos Flask automáticamente con una estructura básica de carpetas y archivos, incluyendo soporte para Docker y configuración de base de datos.

## Instalación

Para instalar Flask Auto, usa pip:

```sh
pip install flask_auto
